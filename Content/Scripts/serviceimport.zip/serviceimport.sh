cd /ccsworker
python run.py
