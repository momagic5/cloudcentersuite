import stdiomask

import warnings
warnings.filterwarnings("ignore")

from common import is_email_valid
from main import initialize

def connection():
    ip_address = None
    while not ip_address:
        ip_address = raw_input("Enter IP Address for Cloud Center Suite:")
        if len(ip_address.strip()) == 0:
            ip_address = None
    
    username = None
    while not username:

        username = raw_input("Enter Cloud Center Suite Email Address : ")
        if not is_email_valid(username):
            username = None
    
    password = None
    while not password:
        password = stdiomask.getpass(prompt='Enter the password: ', mask='*')
        if  len(password.strip()) == 0:
            password = None

    tenant = None
    while not tenant:
        tenant = raw_input("Enter the Tenant Id :")
        if  len(tenant.strip()) == 0:
            tenant = None
    
    
    return {"username":username,"password":password,"tenantName":tenant,"ccm_ip":ip_address}

result = connection()
initialize(result)
