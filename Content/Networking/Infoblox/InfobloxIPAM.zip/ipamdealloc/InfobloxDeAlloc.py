import requests
import os
import sys
import json
import re

#Loads configuration file specified in config.json
def load_config(cfg_file='config.json'):
        """

        :cfg_file: configuration file

        """
        with open(
                os.path.join(
                    os.path.abspath(os.path.dirname(__file__)),
                    cfg_file)) as json_file:
            data = json.load(json_file)
            wapi_version = data['wapi_version']
            ib_hostname = data['ib_hostname']
            ib_user = data['ib_user']
            ib_pass = data['ib_pass']
            ib_dns_view = data['ib_dns_view']
            domain = data['domain']
            dic = {'wapi_version':wapi_version,'ib_hostname':ib_hostname,'ib_user':ib_user,'ib_pass':ib_pass,'domain':domain,'ib_dns_view':ib_dns_view}
            return dic


#Get Infoblox Ipam Config Details
dic = load_config()

hostname = os.getenv('vmName')

fqdn = "{hostname}.{domain}".format(hostname=hostname.lower(), domain=dic['domain'])

ib_api_endpoint = "https://{}/wapi/v{}".format(dic['ib_hostname'], dic['wapi_version'])

rest_url = ib_api_endpoint + '/record:host?name=' + fqdn + '&view='+ dic['ib_dns_view']

#Creating The Session For Each Request Comes From Workload Manager
s = requests.Session()

headers = {}

response = s.request("GET", rest_url, headers=headers,verify=False, auth=(dic['ib_user'], dic['ib_pass']))

try:
    if response.status_code == 200 and "[]" not in response.text:
        host_ref = response.json()[0]['_ref']
        if host_ref and re.match("record:host\/[^:]+:([^\/]+)\/", host_ref).group(1) == fqdn:
            rest_url = 'https://' + dic['ib_hostname'] + '/wapi/v' +  dic['wapi_version'] + '/' + host_ref
            r = requests.delete(url=rest_url, auth=(dic['ib_user'], dic['ib_pass']), verify=False)
            print("Deallocation Of Ip Address Successful")
        else:
            print("Deallocation Of Ip Address Failed")
except:
    print("Deallocation Of Ip Address Failed ")
    sys.exit(1)

