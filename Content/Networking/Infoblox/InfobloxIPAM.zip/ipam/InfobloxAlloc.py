import argparse
import requests
import os
import json
import sys
import netaddr
import urllib3

urllib3.disable_warnings()


#Pulling information from env vars
try:
    os_type = os.getenv("eNV_osName")
    nic_index = 1
    hostname = os.getenv('vmName')
    network_id = os.getenv('networkId')

except Exception as err:
    print("Invalid Environment variable: {0}".format(err))
    sys.exit(1)

#Loads configuration file specified in config.json
def load_config(cfg_file='config.json'):
        """
        :cfg_file: configuration file
        """
        with open(
                os.path.join(
                    os.path.abspath(os.path.dirname(__file__)),
                    cfg_file)) as json_file:
            data = json.load(json_file)
            wapi_version = data['wapi_version']
            ib_hostname = data['ib_hostname']
            ib_user = data['ib_user']
            ib_pass = data['ib_pass']
            domain = data['domain']
            linux_time_zone = data['linux_time_zone']
            dns_server_list = data['dns_server_list']
            dns_suffix_list = data['dns_suffix_list']
            exclude_from_ipam = data['exclude_from_ipam']
            dic = {'wapi_version':wapi_version,'ib_hostname':ib_hostname,'ib_user':ib_user,'ib_pass':ib_pass,'domain':str(domain),
                   'linux_time_zone':str(linux_time_zone),'dns_server_list':str(dns_server_list),'dns_suffix_list':dns_suffix_list,'exclude_from_ipam':exclude_from_ipam}
            return dic

#Retrieving Configuration Properties
dic = load_config()

#Creating The Session For Each Request Comes From Workload Manager
s = requests.Session()

ib_api_endpoint = "https://{}/wapi/v{}".format(dic['ib_hostname'], dic['wapi_version'])

#Return The New Vm Details Based On "exclude_from_ipam" Parameter i.e., Creating Of VM Details By DHCP Or STATIC
def usedhcp():
    if network_id in dic['exclude_from_ipam']:
        use_dhcp = True
    else:
        use_dhcp = False

    if not use_dhcp:
        try:
            ip = allocate_ip()
            content = {'DnsServerList': dic['dns_server_list'],
                       'nicIP_0': str(ip['ip']),
                       'nicDnsServerList_0': dic['dns_server_list'],
                       'nicCount': '1',
                       'nicGateway_0':str(ip['gateway']),
                       'nicNetmask_0':ip['netmask'],
                       'domainName': dic['domain'],
                       'HwClockUTC': 'true',
                       'timeZone': dic['linux_time_zone'],
                       'osHostname':hostname}
            return content
        except Exception as err:
            print("Allocation of Ip Address is not successful: {0}".format(err))
            sys.exit(1)
    else:
        # Echo key/values back to CloudCenter for VM creation
        content = {'nicCount':1,
                   'osHostname': hostname,
                   'nicUseDhcp_0':use_dhcp,
                   'domainName':dic['domain']}
        return content

#Requesting The Ipaddress Using The Response Got From Its Called Method
def get_ip_addr(ref):
    url = "{}/{}".format(ib_api_endpoint, ref)
    try:
        response = s.request("GET", url, verify=False, auth=(dic['ib_user'], dic['ib_pass']))
    except Exception as err:
       print("Couldn't create host record: {0}.".format(err))
       sys.exit(1)

    return response.json()['ipv4addrs'][0]['ipv4addr']

#Requesting To Get The Available Ipaddress In The Given NetworkId And To Create The Host Record And Ipaddress
def allocate_ip():
    # Get network reference
    url = "{}/network".format(ib_api_endpoint)
    querystring = {
        "*NetworkId": network_id,
        "_return_fields": "extattrs,network"
    }
    headers = {}
    response = s.request("GET", url, headers=headers, params=querystring, verify=False,
                         auth=(dic['ib_user'], dic['ib_pass']))
    if len(response.json()) != 1:
        print("Must have exactly one network in Infoblox with "
                      "extensible attribute networkId matching network "
                      "{}. Found {} instead.".format(
                        network_id, response.json()
                        ))
        exit(1)
    gateway = response.json()[0]['extattrs']['Gateway']['value']
    subnet = response.json()[0]['network']
    netmask = str(netaddr.IPNetwork(subnet).netmask)

    # Create Host Record
    url = "{}/record:host".format(ib_api_endpoint)
    fqdn = "{hostname}.{domain}".format(hostname=hostname, domain=dic['domain'])
    payload = {
        "ipv4addrs": [
            {
                "ipv4addr": "func:nextavailableip:{subnet}".format(subnet=subnet)
            }
        ],
        "name": fqdn,
        "configure_for_dns": True
    }
    headers = {'content-type': "application/json"}
    try:
        response = s.request("POST", url, data=json.dumps(payload), headers=headers, verify=False,
                             auth=(dic['ib_user'], dic['ib_pass']))
        response.raise_for_status()
        host_ref = response.json()
    except Exception as err:
        print("Couldn't create host record: {0}.".format(err))
        sys.exit(1)

    #Get Ipaddress Using host_ref
    new_ip = get_ip_addr(host_ref)

    return {
        "ip": new_ip,
        "netmask": netmask,
        "gateway": gateway
    }

if __name__ == '__main__':
    print(usedhcp())
