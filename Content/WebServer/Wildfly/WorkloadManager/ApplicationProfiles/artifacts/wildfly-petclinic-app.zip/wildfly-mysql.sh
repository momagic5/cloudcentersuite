#!/bin/bash


#source /usr/local/osmosix/etc/userenv


function empty
{
    local var="$1"

    # Return true if:
    # 1.    var is a null string ("" as empty string)
    # 2.    a non set variable is passed
    # 3.    a declared variable or array but without a value is passed
    # 4.    an empty array is passed
    if test -z "$var"
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is zero (0 as an integer or "0" as a string)
    elif [ "$var" == 0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is 0.0 (0 as a float)
    elif [ "$var" == 0.0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return
    fi

    [[ $( echo "" ) ]]
}


if empty "${wlfyAppContextName}"
    then
       echo "There is no WebContext"
    else
       echo " Web Context Exist $wlfyAppContextName"
fi



if empty "${wlfyAppConfigFiles}"
    then
       echo "There is no Config Files to Parase"
    else
       echo " Config File exist on $wlfyAppConfigFiles path"
fi

wildfly_name="wildfly16"
wildfly_jdbc="/usr/local/$wildfly_name/webapps/$wlfyAppContextName/$wlfyAppConfigFiles"
jdbc_driver="com.mysql.jdbc.Driver"
jpa_platform="oracle.toplink.essentials.platform.database.MySQL4Platform"
jpa_database="MYSQL"
hibernate_dialect="org.hibernate.dialect.MySQLDialect"
port="3306"
Tier_Class="mysql"

if empty "${CliqrDependencies}"
then
        echo "Dependency Variable is Empty. No further Process."
else

	echo "Dependencies variable has valid Value"
	Tier_Arr=$(echo $CliqrDependencies | tr "," "\n")
	for tier  in $Tier_Arr
        do
            Tier="CliqrTier_${tier}_PUBLIC_IP"
            TIER_IP=${!Tier} 
            
            sed -i  's/^jdbc.url/#jdbc.url/g'  $wildfly_jdbc			 
            
            echo "jdbc.url=jdbc:$Tier_Class://${TIER_IP}:$port/petclinic" >> $wildfly_jdbc  
                
        done

	cd /usr/local/$wildfly_name/webapps/$wlfyAppContextName/
	zip -r $wlfyAppContextName.zip WEB-INF/ static/ META-INF/
	chmod -R 777 $wlfyAppContextName.zip
	cp $wlfyAppContextName.zip /usr/local/$wildfly_name/webapps/$wlfyAppContextName.war
	rm -rf $wlfyAppContextName.zip				
			
fi






