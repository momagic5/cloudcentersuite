#!/bin/bash
set -e
./run.sh keras
